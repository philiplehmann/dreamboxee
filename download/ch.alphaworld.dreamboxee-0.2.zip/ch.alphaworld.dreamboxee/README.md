Dreamboxee
==========

Boxee API Links
---------------
* http://developer.boxee.tv/Applications
* http://developer.boxee.tv/MC_Module

XML Parser BeautifulSoup
------------------------
* http://www.crummy.com/software/BeautifulSoup/

Dreambox API
------------
* http://dream.reichholf.net/wiki/Enigma2:WebInterface#RemoteControl

	<e2eventlist>
		<e2event>
			<e2eventid>11867</e2eventid>
			<e2eventstart>1323204600</e2eventstart>
			<e2eventduration>2100</e2eventduration>
			<e2eventcurrenttime/>
			<e2eventtitle>Alguna pregunta més</e2eventtitle>
			<e2eventdescription></e2eventdescription>
			<e2eventdescriptionextended>Informativos </e2eventdescriptionextended>
			<e2eventservicereference>1:0:1:284:34:1:FFFF01A2:0:0:0:</e2eventservicereference>
			<e2eventservicename>TV Catalunya</e2eventservicename>
		</e2event>
	</e2eventlist>